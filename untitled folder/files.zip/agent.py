"""
agent.py — FarFinder v2 FastAPI backend

Run:
  pip install fastapi uvicorn requests pydantic
  uvicorn agent:app --reload --port 8001

Env vars:
  TRAVELPAYOUTS_TOKEN  — your token (default: hardcoded)
  OPENROUTER_API_KEY   — for NL query parsing (optional, regex fallback used if absent)

Endpoints:
  GET  /health
  POST /search           — structured multi-modal search
  POST /search-nl        — natural language → parse → search
  POST /parse-query      — only parse NL, don't search
  POST /calendar         — price calendar for a route+month
  POST /flexible         — cheapest ±N days around a target date
  POST /budget           — find destinations reachable within a budget
  POST /compare          — comparison table of airports in radius
  POST /trend            — price trend (cheap / normal / expensive)
"""

from __future__ import annotations

import json
import os
import re
from datetime import date, datetime, timedelta
from typing import Optional

import requests
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from airports import (
    geocode_location, find_airports_in_radius,
    resolve_destination_airport, city_to_iata,
)
from flights import (
    get_price_calendar, search_flexible,
    search_by_budget, get_monthly_cheapest,
    classify_price_trend,
)
from routes import build_routes, generate_insights, build_airport_comparison

# ─────────────────────────────────────────────────────────────────────────────
#  APP
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="FarFinder v2 — Multi-Modal Flight Agent",
    description="Powered by Travelpayouts Data API · Finds cheapest flights from nearby airports",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

OPENROUTER_KEY = os.getenv("OPENROUTER_API_KEY")


# ─────────────────────────────────────────────────────────────────────────────
#  PYDANTIC MODELS
# ─────────────────────────────────────────────────────────────────────────────

class SearchReq(BaseModel):
    origin:      str
    destination: str
    date:        str                        # YYYY-MM-DD
    radius_km:   float = 100.0
    adults:      int   = 1
    direct_only: bool  = False

class NLReq(BaseModel):
    query: str

class CalendarReq(BaseModel):
    origin:      str
    destination: str
    month:       str    # YYYY-MM

class FlexibleReq(BaseModel):
    origin:      str
    destination: str
    date:        str    # YYYY-MM-DD
    flex_days:   int = Field(default=3, ge=1, le=14)

class BudgetReq(BaseModel):
    origin:      str
    budget_max:  int   = 5000
    budget_min:  int   = 0
    currency:    str   = "inr"
    direct_only: bool  = False

class CompareReq(BaseModel):
    origin:      str
    destination: str
    date:        str
    radius_km:   float = 150.0

class TrendReq(BaseModel):
    origin:      str
    destination: str


# ─────────────────────────────────────────────────────────────────────────────
#  NL PARSER
# ─────────────────────────────────────────────────────────────────────────────

_PARSE_PROMPT = """You are a flight search query parser. Today is {today}.

Extract and return ONLY this JSON (no markdown, no extra text):
{{
  "origin":      "city name or unknown",
  "destination": "city name or unknown",
  "date":        "YYYY-MM-DD or empty",
  "radius_km":   <number>,
  "adults":      <number>,
  "direct_only": <true|false>,
  "flex_days":   <0 if not flexible, else N>,
  "confidence":  "high|medium|low",
  "note":        "any info"
}}

RULES:
- Indian city aliases: Bombay=Mumbai, Calcutta=Kolkata, Madras=Chennai, Dilli=Delhi, Bengaluru=Bangalore
- Radius keywords: "nearby"=50, "wide"=300, "within X km"=X, absent=100
- "non-stop" or "direct only" → direct_only=true
- "flexible" or "±N days" → flex_days=N (default 3)
- If date unclear → 7 days from today
- Hinglish: "Dilli se Mumbai 15 April 200km mein" → origin=Delhi, destination=Mumbai, radius=200

QUERY: "{query}"
"""


def parse_nl(query: str) -> dict:
    if not OPENROUTER_KEY:
        return _regex_parse(query)
    try:
        r = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {OPENROUTER_KEY}",
                "Content-Type":  "application/json",
            },
            json={
                "model":           "deepseek/deepseek-chat",
                "messages":        [{"role": "user", "content":
                    _PARSE_PROMPT.format(today=date.today().isoformat(), query=query)}],
                "temperature":     0.1,
                "max_tokens":      250,
                "response_format": {"type": "json_object"},
            },
            timeout=18,
        )
        r.raise_for_status()
        return json.loads(r.json()["choices"][0]["message"]["content"])
    except Exception as e:
        print(f"⚠️  LLM parse failed ({e}), using regex")
        return _regex_parse(query)


def _regex_parse(q: str) -> dict:
    ql = q.lower()
    radius = 100.0
    if m := re.search(r"(\d+)\s*km", ql):
        radius = float(m.group(1))
    travel_date = (date.today() + timedelta(days=7)).isoformat()
    if "tomorrow" in ql:
        travel_date = (date.today() + timedelta(days=1)).isoformat()
    elif "next week" in ql:
        travel_date = (date.today() + timedelta(days=7)).isoformat()
    elif m := re.search(r"(\d{1,2})[/\-](\d{1,2})[/\-]?(\d{2,4})?", ql):
        try:
            d, mo = int(m.group(1)), int(m.group(2))
            yr = int(m.group(3)) if m.group(3) else date.today().year
            yr = yr if yr > 99 else 2000 + yr
            travel_date = date(yr, mo, d).isoformat()
        except ValueError:
            pass

    origin, destination = "unknown", "unknown"
    if " to " in ql:
        parts = ql.split(" to ", 1)
        destination = parts[1].strip().split()[0].title()
        for kw in ["from", "fly", "travel"]:
            if kw in parts[0]:
                origin = parts[0].split(kw)[-1].strip().split()[0].title()
                break
    elif " se " in ql:
        parts = ql.split(" se ", 1)
        origin      = parts[0].strip().split()[-1].title()
        destination = parts[1].strip().split()[0].title()

    direct_only = any(w in ql for w in ["non-stop", "nonstop", "direct only"])
    flex_days   = 3 if "flex" in ql else 0

    return {
        "origin": origin, "destination": destination, "date": travel_date,
        "radius_km": radius, "adults": 1, "direct_only": direct_only,
        "flex_days": flex_days, "confidence": "low",
        "note": "Regex fallback — set OPENROUTER_API_KEY for smarter parsing",
    }


# ─────────────────────────────────────────────────────────────────────────────
#  SHARED SEARCH PIPELINE
# ─────────────────────────────────────────────────────────────────────────────

def _run_search(
    origin: str, destination: str,
    travel_date: str, radius_km: float,
    adults: int = 1, direct_only: bool = False,
) -> dict:
    # Validate date
    try:
        td = datetime.strptime(travel_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(400, "Invalid date. Use YYYY-MM-DD.")
    if td < date.today():
        raise HTTPException(400, "Travel date is in the past.")

    # Geocode origin
    coords = geocode_location(origin)
    if not coords:
        raise HTTPException(400, f"Cannot geocode origin: '{origin}'")
    olat, olon = coords

    # Airports in radius
    nearby = find_airports_in_radius(olat, olon, radius_km)
    if not nearby:
        raise HTTPException(404, f"No airports within {radius_km} km of {origin}. Try wider radius.")

    # Destination airport
    dest_ap = resolve_destination_airport(destination)
    if not dest_ap:
        raise HTTPException(400, f"Cannot find airport near '{destination}'.")

    # Build routes
    routes = build_routes(
        nearby_airports=nearby,
        dest_airport=dest_ap,
        departure_date=travel_date,
        origin_city=origin.title(),
        adults=adults,
    )

    # Filter if direct_only
    if direct_only:
        routes = [r for r in routes if r["flight"]["stops"] == 0]

    insights   = generate_insights(routes)
    comparison = build_airport_comparison(routes)

    # Monthly cheapest for context
    origin_iata = nearby[0]["iata"]
    monthly = get_monthly_cheapest(origin_iata, dest_ap["iata"])

    return {
        "search": {
            "origin": origin.title(), "origin_lat": round(olat, 4), "origin_lon": round(olon, 4),
            "destination": destination.title(), "date": travel_date,
            "radius_km": radius_km, "adults": adults, "direct_only": direct_only,
        },
        "airports_checked":    len(nearby),
        "nearby_airports":     nearby,
        "destination_airport": dest_ap,
        "total_routes":        len(routes),
        "routes":              routes[:25],
        "comparison_table":    comparison,
        "insights":            insights,
        "monthly_cheapest":    monthly,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "service": "FarFinder v2", "api": "Travelpayouts Data API"}


@app.post("/parse-query")
def endpoint_parse(req: NLReq):
    return {"query": req.query, "parsed": parse_nl(req.query)}


@app.post("/search")
def endpoint_search(req: SearchReq):
    return _run_search(req.origin, req.destination, req.date, req.radius_km, req.adults, req.direct_only)


@app.post("/search-nl")
def endpoint_search_nl(req: NLReq):
    parsed = parse_nl(req.query)
    if parsed.get("origin", "unknown").lower() == "unknown":
        raise HTTPException(400, "Could not detect origin city. Try: 'Jaipur to Mumbai on 15 April 200km'")
    if parsed.get("destination", "unknown").lower() == "unknown":
        raise HTTPException(400, "Could not detect destination city.")
    result = _run_search(
        origin=parsed["origin"], destination=parsed["destination"],
        travel_date=parsed.get("date") or (date.today() + timedelta(days=7)).isoformat(),
        radius_km=float(parsed.get("radius_km", 100)),
        adults=int(parsed.get("adults", 1)),
        direct_only=bool(parsed.get("direct_only", False)),
    )
    result["parsed_query"] = parsed
    # If flex_days > 0, append flexible results
    if int(parsed.get("flex_days", 0)) > 0:
        try:
            origin_iata = result["nearby_airports"][0]["iata"]
            dest_iata   = result["destination_airport"]["iata"]
            flex = search_flexible(
                origin_iata, dest_iata,
                parsed.get("date") or result["search"]["date"],
                int(parsed["flex_days"]),
            )
            result["flexible_dates"] = flex
        except Exception:
            pass
    return result


@app.post("/calendar")
def endpoint_calendar(req: CalendarReq):
    """Return price calendar (price per day) for origin→dest in given month."""
    origin_iata = city_to_iata(req.origin) or req.origin.upper()
    dest_iata   = city_to_iata(req.destination) or req.destination.upper()

    # If city names given, try to resolve
    if len(origin_iata) != 3:
        coords = geocode_location(req.origin)
        if coords:
            nearby = find_airports_in_radius(*coords, 60)
            origin_iata = nearby[0]["iata"] if nearby else origin_iata

    if len(dest_iata) != 3:
        dest_ap = resolve_destination_airport(req.destination)
        dest_iata = dest_ap["iata"] if dest_ap else dest_iata

    calendar = get_price_calendar(origin_iata, dest_iata, req.month)

    if not calendar:
        return {
            "origin": origin_iata, "destination": dest_iata,
            "month": req.month, "calendar": {}, "cheapest_day": None,
        }

    cheapest_day = min(calendar.items(), key=lambda x: x[1]["price"])
    return {
        "origin":      origin_iata,
        "destination": dest_iata,
        "month":       req.month,
        "calendar":    calendar,
        "cheapest_day": {
            "date":    cheapest_day[0],
            "price":   cheapest_day[1]["price"],
            "airline": cheapest_day[1]["airline"],
        },
        "days_with_data": len(calendar),
    }


@app.post("/flexible")
def endpoint_flexible(req: FlexibleReq):
    """Find cheapest day within ±flex_days of the target date."""
    origin_iata = city_to_iata(req.origin) or req.origin.upper()
    dest_iata   = city_to_iata(req.destination) or req.destination.upper()

    if len(origin_iata) != 3:
        coords = geocode_location(req.origin)
        if coords:
            nearby = find_airports_in_radius(*coords, 60)
            origin_iata = nearby[0]["iata"] if nearby else origin_iata

    if len(dest_iata) != 3:
        dest_ap = resolve_destination_airport(req.destination)
        dest_iata = dest_ap["iata"] if dest_ap else dest_iata

    results = search_flexible(origin_iata, dest_iata, req.date, req.flex_days)
    target_entry = next((r for r in results if r["is_target"]), None)
    cheapest     = results[0] if results else None

    savings = 0
    if target_entry and cheapest and target_entry["price"] != cheapest["price"]:
        savings = target_entry["price"] - cheapest["price"]

    return {
        "origin":       origin_iata,
        "destination":  dest_iata,
        "target_date":  req.date,
        "flex_days":    req.flex_days,
        "options":      results,
        "cheapest_day": cheapest,
        "target_price": target_entry["price"] if target_entry else None,
        "savings_if_flexible": savings,
    }


@app.post("/budget")
def endpoint_budget(req: BudgetReq):
    """Find all destinations reachable from origin within budget."""
    origin_iata = city_to_iata(req.origin) or req.origin.upper()
    if len(origin_iata) != 3:
        coords = geocode_location(req.origin)
        if coords:
            nearby = find_airports_in_radius(*coords, 60)
            origin_iata = nearby[0]["iata"] if nearby else origin_iata

    destinations = search_by_budget(
        origin=origin_iata,
        budget_min=req.budget_min,
        budget_max=req.budget_max,
        currency=req.currency,
        direct_only=req.direct_only,
    )
    return {
        "origin":       origin_iata,
        "budget_max":   req.budget_max,
        "currency":     req.currency,
        "destinations": destinations,
        "count":        len(destinations),
    }


@app.post("/compare")
def endpoint_compare(req: CompareReq):
    """Return airport comparison table without full route details."""
    result = _run_search(req.origin, req.destination, req.date, req.radius_km)
    return {
        "search":           result["search"],
        "comparison_table": result["comparison_table"],
        "insights":         result["insights"],
    }


@app.post("/trend")
def endpoint_trend(req: TrendReq):
    """Check if a route's prices are currently cheap / normal / expensive."""
    origin_iata = city_to_iata(req.origin) or req.origin.upper()
    dest_iata   = city_to_iata(req.destination) or req.destination.upper()

    monthly = get_monthly_cheapest(origin_iata, dest_iata)
    if not monthly:
        return {"origin": origin_iata, "destination": dest_iata, "trend": "unknown", "monthly": []}

    best_price = monthly[0]["price"] if monthly else 0
    trend      = classify_price_trend(origin_iata, dest_iata, best_price)

    return {
        "origin":      origin_iata,
        "destination": dest_iata,
        "best_price":  best_price,
        "trend":       trend,
        "monthly":     monthly,
    }
